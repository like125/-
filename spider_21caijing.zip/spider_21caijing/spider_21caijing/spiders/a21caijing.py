# -*- coding: utf-8 -*-
import scrapy
from spider_21caijing.items import Spider21CaijingItem

class A21jingjiSpider(scrapy.Spider):
    name = '21jingji'
    allowed_domains = ['a']
    start_urls = ['https://m.21jingji.com/reader/index?more=1&page=2&type=json',
                  'https://m.21jingji.com/reader/index?more=1&page=3&type=json',
                  'https://m.21jingji.com/reader/index?more=1&page=4&type=json',
                  'https://m.21jingji.com/reader/index?more=1&page=5&type=json']

    def parse(self, response):
        item=Spider21CaijingItem()
        body=response.xpath('/html/body').extract()
        body=body[0].split('<body><p>')[1].split('</p></body>')[0]
        body=body.split('{"')
        for i in body:
            try:
                url=i.split('"url":"')[1].split('","list')[0]
                string = ""
                u = url.split('/')
                for it in u:
                    string = string + it
            except:
                string=" "
            item['url']=string
            yield item
